import { useEffect } from 'react';

export default function App() {
  useEffect(() => {
    console.log('[KK] All runtime content view loaded');
  }, []);

  return <div className="kk-all-runtime-content-view-text">All runtime content view</div>;
}
