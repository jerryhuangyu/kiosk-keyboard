import { useEffect } from 'react';

export default function App() {
  useEffect(() => {
    console.log('[KK] Example runtime content view loaded');
  }, []);

  return <div className="kk-example-runtime-content-view-text">Example runtime content view</div>;
}
