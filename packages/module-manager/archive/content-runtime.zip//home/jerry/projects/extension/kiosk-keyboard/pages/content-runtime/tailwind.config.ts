import { withUI } from '@extension/ui';

export default withUI({
  content: ['src/**/*.tsx'],
});
